<div id="navigation" class="span-4">
  <ul>
    <li id="nav_i"><a href="index.php">Article I</a></li>
    <li id="nav_ii"><a href="ii.php">Article II</a></li>
    <li id="nav_iii"><a href="iii.php">Article III</a></li>
    <li id="nav_iv"><a href="iv.php">Article IV</a></li>
    <li id="nav_v"><a href="v.php">Article V</a></li>
    <li id="nav_vi"><a href="vi.php">Article VI</a></li>
    <li id="nav_vii"><a href="vii.php">Article VII</a></li>
    <li id="nav_amendments"><a href="amendments.php">Amendments</a></li>
  </ul>
</div>