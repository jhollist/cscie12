<div id="footer" class="span-24 last">
    <p>This XHTML version of the United States Constitution was adapted from <a href="http://www.house.gov/">U.S. House of Representatives</a> website at <a href="http://www.house.gov/house/Constitution/Constitution.html">http://www.house.gov/Constitution/Constitution.html</a>. <br/>
      <a href="http://www.archives.gov/exhibits/charters/constitution.html">Learn more about the United States Constitution at <strong>The National Archives</strong> online exhibit</a>.</p>
  <div>
    Document URI: <!--#echo var="DOCUMENT_URI"--><br/>
    Server Name:  <!--#echo var="SERVER_NAME"--><br/>
    Last Modified:  <!--#echo var="LAST_MODIFIED"--><br/>
  </div>
</div>